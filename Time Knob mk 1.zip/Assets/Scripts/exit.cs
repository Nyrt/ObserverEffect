﻿using UnityEngine;
using System.Collections;

public class exit : MonoBehaviour {

	public int number;
}
