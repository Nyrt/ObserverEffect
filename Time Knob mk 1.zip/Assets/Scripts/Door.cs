﻿using UnityEngine;
using System.Collections;

public class Door : MonoBehaviour {

	private float openTime = 999;
	public bool open = false;
	public float openDelay;

	private Vector3 closedPosition;
	private Vector3 openPosition;
	private Quaternion closedRotation;
	private Quaternion openRotation;

	public void toggle(float time){
		openTime = time;
	}

	public void setStatus(float time){
		if (time > openTime + openDelay) {
			open = true;
			transform.position = Vector3.Lerp (transform.position, openPosition, 0.1f);
			transform.rotation = Quaternion.Lerp (transform.rotation, openRotation, 0.1f);
		} else {
			transform.position  = Vector3.Lerp (transform.position, closedPosition, 0.1f);
			transform.rotation = Quaternion.Lerp (transform.rotation, closedRotation, 0.1f);
		}
	}

	// Use this for initialization
	void Start () {
		closedPosition = transform.position;
		closedRotation = transform.rotation;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
